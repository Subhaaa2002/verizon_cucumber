package cucumberOptions_1;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features="src//test//java//features",glue="stepDefinition1",tags="@CatalogAPITest")
public class TestRunner {

}
//@CatalogAPITest
//@OrderAPITest
//@EnterpriseAPITest
//@ServiceAPITest
//@OrderEnterpriseAPITest