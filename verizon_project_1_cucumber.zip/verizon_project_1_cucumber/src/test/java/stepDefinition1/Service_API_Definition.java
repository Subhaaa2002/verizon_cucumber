package stepDefinition1;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Service_API_Definition {
	
	@Given("User is on service provisioning page1 outline")
	public void user_is_on_service_provisioning_page1_outline() {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("Given_1");
	}

	@When("User wants to {string} api service provision outline")
	public void user_wants_to_api_service_provision_outline(String string) {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("When_1");
	}

	@Then("User can access the service provisioning page1 outline")
	public void user_can_access_the_service_provisioning_page1_outline() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Then_1");
	}

	@Given("User is on service provisioning page2 outline")
	public void user_is_on_service_provisioning_page2_outline() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Given_2");
	}

	@When("User wants to {string} api service test-qos outline")
	public void user_wants_to_api_service_test_qos_outline(String string) {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("When_2");
	}

	@Then("User can access the service provisioning page2 outline")
	public void user_can_access_the_service_provisioning_page2_outline() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Then_2");
	}

	@Given("User is on service provisioning page3 outline")
	public void user_is_on_service_provisioning_page3_outline() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Given_3");
	}

	@When("User wants to {string} api service disable {string} outline")
	public void user_wants_to_api_service_disable_outline(String string, String string2) {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("When_3");
	}

	@Then("User can access the service provisioning page3 outline")
	public void user_can_access_the_service_provisioning_page3_outline() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Then_3");
	}

	@Given("User is on service provisioning page4 outline")
	public void user_is_on_service_provisioning_page4_outline() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Given_4");
	}

	@When("User wants to {string} api service hold {string} outline")
	public void user_wants_to_api_service_hold_outline(String string, String string2) {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("When_4");
	}

	@Then("User can access the service provisioning page4 outline")
	public void user_can_access_the_service_provisioning_page4_outline() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Then_4");
	}

	@Given("User is on service provisioning page5 outline")
	public void user_is_on_service_provisioning_page5_outline() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Given_5");
	}

	@When("User wants to {string} api service resume {string} outline")
	public void user_wants_to_api_service_resume_outline(String string, String string2) {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("When_5");
	}

	@Then("User can access the service provisioning page5 outline")
	public void user_can_access_the_service_provisioning_page5_outline() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Then_5");
	}

	
}