package stepDefinition1;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Order_API_Definition {
	
	@Given("User is on order page1 outline")
	public void user_is_on_order_page1_outline() {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("Given_1");
	}

	@When("User wants to {string} api consumer customer {string} orders outline")
	public void user_wants_to_api_consumer_customer_orders_outline(String string, String string2) {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("When_1");
	}

	@Then("User can access the order page1 outline")
	public void user_can_access_the_order_page1_outline() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Then_1");
	}

	@Given("User is on order page2 outline")
	public void user_is_on_order_page2_outline() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Given_2");
	}

	@When("User wants to {string} api consumer customer {string} orders {string} outline")
	public void user_wants_to_api_consumer_customer_orders_outline(String string, String string2, String string3) {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("When_2");
	}

	@Then("User can access the order page2 outline")
	public void user_can_access_the_order_page2_outline() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Then_2");
	}

	@Given("User is on order page3 outline")
	public void user_is_on_order_page3_outline() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Given_3");
	}

	@When("User wants to {string} api consumer orders {string} outline")
	public void user_wants_to_api_consumer_orders_outline(String string, String string2) {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("When_3");
	}

	@Then("User can access the order page3 outline")
	public void user_can_access_the_order_page3_outline() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Then_3");
	}

	@Given("User is on order page4 outline")
	public void user_is_on_order_page4_outline() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Given_4");
	}

	@When("User wants to {string} api consumer orders status {string} outline")
	public void user_wants_to_api_consumer_orders_status_outline(String string, String string2) {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("When_4");
	}

	@Then("User can access the order page4 outline")
	public void user_can_access_the_order_page4_outline() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Then_4");
	}


}
