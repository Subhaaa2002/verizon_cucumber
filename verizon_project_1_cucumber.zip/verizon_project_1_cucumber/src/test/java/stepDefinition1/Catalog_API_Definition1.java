package stepDefinition1;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Catalog_API_Definition1 {
	
	@Given("User is on catalog page1 outline")
	public void user_is_on_catalog_page1_outline() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Given_1");
	}

	@When("User wants to {string} api catalog outline")
	public void user_wants_to_api_catalog_outline(String string) {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("When_1");
	}

	@Then("User can access the catalog page1 outline")
	public void user_can_access_the_catalog_page1_outline() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Then_1");
	}

	@Given("User is on catalog page2 outline")
	public void user_is_on_catalog_page2_outline() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Given_2");
	}

	@When("User wants to {string} api catalog {string} outline")
	public void user_wants_to_api_catalog_outline(String string, String string2) {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("When_2");
	}

	@Then("User can access the catalog page2 outline")
	public void user_can_access_the_catalog_page2_outline() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Then_2");
	}



}
