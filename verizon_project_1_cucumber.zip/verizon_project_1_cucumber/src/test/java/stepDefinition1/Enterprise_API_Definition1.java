package stepDefinition1;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Enterprise_API_Definition1 {
	@Given("User is on Enterprise customers page1 outline")
	public void user_is_on_enterprise_customers_page1_outline() {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("Given_1");
	}

	@When("User wants to {string} api enterprise customers outline")
	public void user_wants_to_api_enterprise_customers_outline(String string) {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("When_1");
	}

	@Then("User can access the Enterprise customers page1 outline")
	public void user_can_access_the_enterprise_customers_page1_outline() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Then_1");
	}

	@Given("User is on Enterprise customers page2 outline")
	public void user_is_on_enterprise_customers_page2_outline() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Given_2");
	}

	@When("User wants to {string} api enterprise customers {string} outline")
	public void user_wants_to_api_enterprise_customers_outline(String string, String string2) {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("When_2");
	}

	@Then("User can access the Enterprise customers page2 outline")
	public void user_can_access_the_enterprise_customers_page2_outline() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Then_2");
	}


}
